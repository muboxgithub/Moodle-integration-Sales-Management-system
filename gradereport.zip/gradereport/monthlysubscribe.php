<?PHP
include('../connection.php');




$duration='[1]';
$duration2='["1"]';

$sqlgrade9="SELECT COUNT(*) as totalpayedpromo FROM ( SELECT id FROM `transaction_bank` WHERE `promo` IS NOT NULL AND `promo` NOT IN ('telegram', 'whatsapp', 'facebook', 'friends', 'others') AND status = 2 AND `duration` IN (?, ?) UNION ALL SELECT id FROM checkout WHERE `promo` IS NOT NULL AND `promo` NOT IN ('telegram', 'whatsapp', 'facebook', 'friends', 'others') AND status = 1 AND `duration` IN (?, ?) ) AS combined_tables";

$stmtgrade=$conn3->prepare($sqlgrade9);

$stmtgrade->bind_param('ssss', $duration, $duration2,$duration, $duration2);
$stmtgrade->execute();


$resultgrade=$stmtgrade->get_result();


if($resultgrade->num_rows>0){

   $row=$resultgrade->fetch_assoc();
   echo $row['totalpayedpromo'];
}
else{
    echo "0";
}




?>